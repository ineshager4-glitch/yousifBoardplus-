package com.yousif.boardplus.whiteboard.engine

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import com.yousif.boardplus.whiteboard.model.PenType
import com.yousif.boardplus.whiteboard.model.Pt
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * يحوّل نقاط الخط إلى مضلع مملوء بعرض متغير (ضغط القلم / زاوية الريشة) في Path واحد.
 * مسار واحد مملوء = رسم سريع، وبلا تراكم شفافية عند تقاطع الخط مع نفسه (مهم للهايلايتر).
 */
object StrokeOutline {

    fun penAlpha(pen: PenType): Float = if (pen == PenType.PENCIL) 0.85f else 1f

    private fun halfWidths(pen: PenType, width: Float, pts: List<Pt>): FloatArray {
        val n = pts.size
        val hw = FloatArray(n)
        val base = width / 2f
        for (i in 0 until n) {
            val p = pts[i].p.coerceIn(0.05f, 1f)
            hw[i] = when (pen) {
                PenType.PEN -> base * (0.4f + 0.6f * p)
                PenType.PENCIL -> base * 0.8f * (0.5f + 0.5f * p)
                PenType.MARKER, PenType.HIGHLIGHTER -> base
                PenType.CALLIGRAPHY -> {
                    val a = pts[max(i - 1, 0)]; val b = pts[min(i + 1, n - 1)]
                    val theta = atan2(b.y - a.y, b.x - a.x)
                    val nib = (PI / 4.0).toFloat() // زاوية رأس الريشة 45°
                    base * (0.25f + 0.75f * abs(sin(theta - nib))) * (0.7f + 0.3f * p)
                }
            }
        }
        // تنعيم بسيط للعرض لتفادي القفزات
        if (n > 2 && pen != PenType.MARKER && pen != PenType.HIGHLIGHTER) {
            val s = hw.copyOf()
            for (i in 1 until n - 1) hw[i] = (s[i - 1] + 2f * s[i] + s[i + 1]) / 4f
        }
        return hw
    }

    fun build(pen: PenType, width: Float, pts: List<Pt>): Path {
        val path = Path()
        val n = pts.size
        if (n == 0) return path
        val hw = halfWidths(pen, width, pts)
        if (n == 1) {
            path.addOval(Rect(Offset(pts[0].x, pts[0].y), max(hw[0], 0.5f)))
            return path
        }
        val lx = FloatArray(n); val ly = FloatArray(n)
        val rx = FloatArray(n); val ry = FloatArray(n)
        for (i in 0 until n) {
            val a = pts[max(i - 1, 0)]; val b = pts[min(i + 1, n - 1)]
            var dx = b.x - a.x; var dy = b.y - a.y
            val len = hypot(dx, dy)
            if (len < 1e-6f) { dx = 1f; dy = 0f } else { dx /= len; dy /= len }
            val nx = -dy; val ny = dx
            lx[i] = pts[i].x + nx * hw[i]; ly[i] = pts[i].y + ny * hw[i]
            rx[i] = pts[i].x - nx * hw[i]; ry[i] = pts[i].y - ny * hw[i]
        }
        path.moveTo(lx[0], ly[0])
        for (i in 1 until n) {
            path.quadraticBezierTo(lx[i - 1], ly[i - 1], (lx[i - 1] + lx[i]) / 2f, (ly[i - 1] + ly[i]) / 2f)
        }
        path.lineTo(lx[n - 1], ly[n - 1])
        path.lineTo(rx[n - 1], ry[n - 1])
        for (i in n - 1 downTo 1) {
            path.quadraticBezierTo(rx[i], ry[i], (rx[i] + rx[i - 1]) / 2f, (ry[i] + ry[i - 1]) / 2f)
        }
        path.lineTo(rx[0], ry[0])
        path.close()
        if (pen != PenType.CALLIGRAPHY) {
            path.addOval(Rect(Offset(pts[0].x, pts[0].y), max(hw[0], 0.5f)))
            path.addOval(Rect(Offset(pts[n - 1].x, pts[n - 1].y), max(hw[n - 1], 0.5f)))
        }
        return path
    }
}
