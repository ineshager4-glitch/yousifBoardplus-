package com.yousif.boardplus.whiteboard.history

import com.yousif.boardplus.whiteboard.model.Element

/**
 * تعديل قابل للعكس على قائمة عناصر الصفحة. نخزّن التغيير فقط (وليس نسخة كاملة)
 * فتبقى الذاكرة صغيرة حتى مع آلاف العمليات.
 */
sealed interface Edit {
    fun apply(list: List<Element>): List<Element>
    fun inverse(): Edit

    /** إدراج عناصر عند مواقعها (z-order). */
    data class Insert(val items: List<Pair<Int, Element>>) : Edit {
        override fun apply(list: List<Element>): List<Element> {
            val out = list.toMutableList()
            for ((i, e) in items.sortedBy { it.first }) out.add(i.coerceIn(0, out.size), e)
            return out
        }
        override fun inverse(): Edit = Delete(items)
    }

    /** حذف عناصر مع تذكّر مواقعها الأصلية. */
    data class Delete(val items: List<Pair<Int, Element>>) : Edit {
        override fun apply(list: List<Element>): List<Element> {
            val ids = items.mapTo(HashSet()) { it.second.id }
            return list.filterNot { it.id in ids }
        }
        override fun inverse(): Edit = Insert(items.sortedBy { it.first })
    }

    /** استبدال عناصر بنفس المعرّف (تحريك، تغيير حجم، تدوير، تعديل نص). */
    data class Update(val before: List<Element>, val after: List<Element>) : Edit {
        override fun apply(list: List<Element>): List<Element> {
            val map = after.associateBy { it.id }
            return list.map { map[it.id] ?: it }
        }
        override fun inverse(): Edit = Update(after, before)
    }

    data class Composite(val edits: List<Edit>) : Edit {
        override fun apply(list: List<Element>): List<Element> = edits.fold(list) { acc, e -> e.apply(acc) }
        override fun inverse(): Edit = Composite(edits.asReversed().map { it.inverse() })
    }
}

/** يحسب التعديل الذي يحوّل before إلى after (للحذف/الإضافة فقط، حسب المعرّف). */
fun diffEdit(before: List<Element>, after: List<Element>): Edit? {
    val beforeIds = before.mapTo(HashSet()) { it.id }
    val afterIds = after.mapTo(HashSet()) { it.id }
    val deleted = before.withIndex().filter { it.value.id !in afterIds }.map { it.index to it.value }
    val added = after.withIndex().filter { it.value.id !in beforeIds }.map { it.index to it.value }
    val edits = buildList<Edit> {
        if (deleted.isNotEmpty()) add(Edit.Delete(deleted))
        if (added.isNotEmpty()) add(Edit.Insert(added))
    }
    return when (edits.size) {
        0 -> null
        1 -> edits[0]
        else -> Edit.Composite(edits)
    }
}

/** سجل تراجع/إعادة. الحد الافتراضي 10,000 عملية. */
class EditHistory(private val limit: Int = 10_000) {
    private val undoStack = ArrayDeque<Edit>()
    private val redoStack = ArrayDeque<Edit>()

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    fun record(edit: Edit) {
        undoStack.addLast(edit)
        redoStack.clear()
        while (undoStack.size > limit) undoStack.removeFirst()
    }

    fun undo(list: List<Element>): List<Element>? {
        val e = undoStack.removeLastOrNull() ?: return null
        redoStack.addLast(e)
        return e.inverse().apply(list)
    }

    fun redo(list: List<Element>): List<Element>? {
        val e = redoStack.removeLastOrNull() ?: return null
        undoStack.addLast(e)
        return e.apply(list)
    }

    fun clear() { undoStack.clear(); redoStack.clear() }
}
