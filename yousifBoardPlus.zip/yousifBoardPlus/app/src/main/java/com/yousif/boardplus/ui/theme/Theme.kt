package com.yousif.boardplus.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val Dark = darkColorScheme(
    primary = YbpColors.Electric,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    background = YbpColors.NavyDeep,
    onBackground = androidx.compose.ui.graphics.Color.White,
    surface = YbpColors.Navy,
    onSurface = androidx.compose.ui.graphics.Color.White,
    surfaceVariant = YbpColors.NavySurface,
    onSurfaceVariant = YbpColors.ElectricSoft,
    error = YbpColors.Danger,
)

private val Light = lightColorScheme(
    primary = YbpColors.Electric,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    background = YbpColors.Paper,
    onBackground = YbpColors.Ink,
    surface = androidx.compose.ui.graphics.Color.White,
    onSurface = YbpColors.Ink,
    surfaceVariant = YbpColors.ElectricSoft,
    onSurfaceVariant = YbpColors.Navy,
    error = YbpColors.Danger,
)

/** darkTheme: null = اتباع النظام. سيُربط بالإعدادات في المرحلة 13. */
@Composable
fun YousifBoardTheme(darkTheme: Boolean? = null, content: @Composable () -> Unit) {
    val dark = darkTheme ?: isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = if (dark) Dark else Light,
        typography = YbpTypography,
        content = content,
    )
}
