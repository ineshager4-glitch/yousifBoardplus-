package com.yousif.boardplus.ui.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.yousif.boardplus.R
import com.yousif.boardplus.ui.theme.YbpColors
import kotlinx.coroutines.delay

/** شاشة البداية: شعار يُرسم تدريجيًا (animation خفيفة) ثم الانتقال إلى Dashboard. */
@Composable
fun SplashScreen(onFinished: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val textAlpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(durationMillis = 700))
        textAlpha.animateTo(1f, tween(durationMillis = 300))
        delay(350)
        onFinished()
    }

    Box(
        modifier = Modifier.fillMaxSize().background(YbpColors.Navy).systemBarsPadding(),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Canvas(modifier = Modifier.size(160.dp)) {
                val w = size.width
                val h = size.height
                val strokeW = w * 0.035f
                // إطار السبورة
                drawRoundRect(
                    color = Color.White.copy(alpha = progress.value),
                    topLeft = Offset(w * 0.08f, h * 0.18f),
                    size = Size(w * 0.84f, h * 0.56f),
                    cornerRadius = CornerRadius(w * 0.06f),
                    style = Stroke(width = strokeW),
                )
                // حرف Y
                val y = Path().apply {
                    moveTo(w * 0.34f, h * 0.30f)
                    lineTo(w * 0.50f, h * 0.48f)
                    lineTo(w * 0.66f, h * 0.30f)
                    moveTo(w * 0.50f, h * 0.48f)
                    lineTo(w * 0.50f, h * 0.60f)
                }
                drawPath(
                    y, Color.White.copy(alpha = progress.value),
                    style = Stroke(width = strokeW * 1.5f, cap = StrokeCap.Round, join = StrokeJoin.Round),
                )
                // خط القلم الأزرق
                drawLine(
                    color = YbpColors.Electric,
                    start = Offset(w * 0.28f, h * 0.88f),
                    end = Offset(w * (0.28f + 0.44f * progress.value), h * 0.88f),
                    strokeWidth = strokeW * 1.3f,
                    cap = StrokeCap.Round,
                )
            }
            Spacer(Modifier.height(24.dp))
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.displaySmall,
                color = Color.White,
                modifier = Modifier.alpha(textAlpha.value),
            )
            Text(
                text = stringResource(R.string.tagline),
                style = MaterialTheme.typography.bodyLarge,
                color = YbpColors.ElectricSoft,
                modifier = Modifier.padding(top = 8.dp).alpha(textAlpha.value),
            )
        }
    }
}
