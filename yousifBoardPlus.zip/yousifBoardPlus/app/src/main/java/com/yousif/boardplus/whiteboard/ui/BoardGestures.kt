package com.yousif.boardplus.whiteboard.ui

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerId
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.changedToDown
import androidx.compose.ui.input.pointer.positionChanged
import com.yousif.boardplus.whiteboard.engine.BoardController

private enum class Mode { NONE, DRAW, GESTURE }

/**
 * نظام اللمس:
 *  - إصبعان أو أكثر: تحريك + تكبير (يلغي أي رسم بدأه إصبع).
 *  - القلم الإلكتروني: يرسم دائمًا؛ ولمس اليد بعده يُستخدم للتحريك فقط (Palm rejection).
 *  - زر ممحاة القلم يمسح مؤقتًا. عجلة الفأرة تكبّر وتصغّر.
 */
suspend fun PointerInputScope.boardGestures(c: BoardController) {
    awaitPointerEventScope {
        var mode = Mode.NONE
        var activeId: PointerId? = null
        var prevCentroid = Offset.Zero
        var prevSpan = 0f

        while (true) {
            val event = awaitPointerEvent()
            val changes = event.changes

            if (changes.any { it.type == PointerType.Stylus || it.type == PointerType.Eraser }) c.noteStylus()

            if (event.type == PointerEventType.Scroll) {
                val ch = changes.first()
                c.zoomAround(ch.position, if (ch.scrollDelta.y > 0f) 0.9f else 1.1f)
                ch.consume()
                continue
            }

            val touches = changes.filter { it.pressed && it.type == PointerType.Touch }

            // ── إيماءة إصبعين ──
            if (touches.size >= 2) {
                if (mode == Mode.DRAW) { c.cancelInteraction(); activeId = null }
                var sx = 0f; var sy = 0f
                for (t in touches) { sx += t.position.x; sy += t.position.y }
                val cen = Offset(sx / touches.size, sy / touches.size)
                var span = 0f
                for (t in touches) span += (t.position - cen).getDistance()
                span /= touches.size
                if (mode != Mode.GESTURE) {
                    mode = Mode.GESTURE
                } else {
                    c.transformView(cen, prevCentroid, if (prevSpan > 1f) span / prevSpan else 1f)
                }
                prevCentroid = cen; prevSpan = span
                changes.forEach { it.consume() }
                continue
            }

            if (mode == Mode.GESTURE) {
                if (changes.none { it.pressed }) mode = Mode.NONE
                changes.forEach { it.consume() }
                continue
            }

            // ── بدء تفاعل ──
            if (mode == Mode.NONE) {
                val down = changes.firstOrNull { it.changedToDown() } ?: continue
                val isTouch = down.type == PointerType.Touch
                if (isTouch && !c.fingerCanDraw()) {
                    c.beginPan(down.position)
                } else {
                    val pressure = if (isTouch) 1f else down.pressure.coerceIn(0.1f, 1f)
                    c.beginInteraction(down.position, pressure, down.type == PointerType.Eraser)
                }
                activeId = down.id
                mode = Mode.DRAW
                down.consume()
                continue
            }

            // ── متابعة تفاعل ──
            val ch = changes.firstOrNull { it.id == activeId }
            if (ch == null) { c.cancelInteraction(); mode = Mode.NONE; activeId = null; continue }
            if (!ch.pressed) {
                c.endInteraction()
                mode = Mode.NONE; activeId = null
                ch.consume()
                continue
            }
            if (ch.positionChanged()) {
                val pressure = if (ch.type == PointerType.Touch) 1f else ch.pressure.coerceIn(0.1f, 1f)
                c.moveInteraction(ch.position, pressure)
                ch.consume()
            }
        }
    }
}
