package com.yousif.boardplus

import android.app.Application

/** نقطة بدء التطبيق. التهيئة الثقيلة تتم كسولًا (lazy) لتسريع الإقلاع. */
class YousifBoardApp : Application()
