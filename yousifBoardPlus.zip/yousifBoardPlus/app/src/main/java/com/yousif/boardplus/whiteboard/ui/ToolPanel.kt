package com.yousif.boardplus.whiteboard.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.FormatAlignCenter
import androidx.compose.material.icons.rounded.FormatAlignLeft
import androidx.compose.material.icons.rounded.FormatAlignRight
import androidx.compose.material.icons.rounded.FormatBold
import androidx.compose.material.icons.rounded.FormatItalic
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.yousif.boardplus.R
import com.yousif.boardplus.ui.theme.YbpColors
import com.yousif.boardplus.whiteboard.engine.BoardController
import com.yousif.boardplus.whiteboard.engine.BoardPalette
import com.yousif.boardplus.whiteboard.engine.EraserMode
import com.yousif.boardplus.whiteboard.engine.Tool
import com.yousif.boardplus.whiteboard.model.PenType
import com.yousif.boardplus.whiteboard.model.ShapeType
import com.yousif.boardplus.whiteboard.model.TextElement

/** لوحة خيارات ذكية: تعرض فقط ما يخص الأداة الحالية لتقليل الازدحام. */
@Composable
fun ToolPanel(c: BoardController, modifier: Modifier = Modifier) {
    Column(
        modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        when (c.tool) {
            Tool.PEN -> { PenTypeChips(c); StyleControls(c, Tool.PEN, 1f..30f) }
            Tool.MARKER -> StyleControls(c, Tool.MARKER, 2f..40f)
            Tool.HIGHLIGHTER -> StyleControls(c, Tool.HIGHLIGHTER, 10f..80f)
            Tool.ERASER -> EraserControls(c)
            Tool.SHAPES -> ShapeControls(c)
            Tool.TEXT -> TextControls(c, null)
            Tool.SELECT -> {
                val sel = c.selected
                if (sel is TextElement) TextControls(c, sel)
                else Text(
                    stringResource(R.string.sel_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun PenTypeChips(c: BoardController) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(
            PenType.PEN to R.string.pen_pen,
            PenType.PENCIL to R.string.pen_pencil,
            PenType.CALLIGRAPHY to R.string.pen_calligraphy,
        ).forEach { (type, label) ->
            FilterChip(
                selected = c.penType == type,
                onClick = { c.penType = type },
                label = { Text(stringResource(label), style = MaterialTheme.typography.labelLarge) },
                modifier = Modifier.height(48.dp),
            )
        }
    }
}

@Composable
private fun StyleControls(c: BoardController, tool: Tool, sizeRange: ClosedFloatingPointRange<Float>) {
    val st = c.style(tool)
    SectionLabel(R.string.opt_color)
    ColorPalette(st.color) { col -> c.updateStyle(tool) { it.copy(color = col) } }
    SectionLabel(R.string.opt_size)
    Slider(
        value = st.size.coerceIn(sizeRange.start, sizeRange.endInclusive),
        onValueChange = { v -> c.updateStyle(tool) { it.copy(size = v) } },
        valueRange = sizeRange,
    )
    SectionLabel(R.string.opt_opacity)
    Slider(
        value = st.opacity,
        onValueChange = { v -> c.updateStyle(tool) { it.copy(opacity = v) } },
        valueRange = 0.1f..1f,
    )
}

@Composable
private fun EraserControls(c: BoardController) {
    FlowRowChips(
        listOf(
            EraserMode.PIXEL to R.string.erase_pixel,
            EraserMode.STROKE to R.string.erase_stroke,
            EraserMode.OBJECT to R.string.erase_object,
            EraserMode.AREA to R.string.erase_area,
        ),
        selected = c.eraserMode,
    ) { c.eraserMode = it }
    SectionLabel(R.string.opt_size)
    Slider(value = c.eraserSize, onValueChange = { c.eraserSize = it }, valueRange = 16f..160f)
}

@Composable
private fun ShapeControls(c: BoardController) {
    FlowRowChips(
        listOf(
            ShapeType.LINE to R.string.sh_line, ShapeType.ARROW to R.string.sh_arrow,
            ShapeType.RECTANGLE to R.string.sh_rect, ShapeType.ROUNDED_RECT to R.string.sh_rounded,
            ShapeType.CIRCLE to R.string.sh_circle, ShapeType.ELLIPSE to R.string.sh_ellipse,
            ShapeType.TRIANGLE to R.string.sh_triangle, ShapeType.POLYGON to R.string.sh_polygon,
            ShapeType.STAR to R.string.sh_star,
        ),
        selected = c.shapeType,
    ) { c.shapeType = it }
    FilterChip(
        selected = c.shapeFill,
        onClick = { c.shapeFill = !c.shapeFill },
        label = { Text(stringResource(R.string.sh_fill), style = MaterialTheme.typography.labelLarge) },
        modifier = Modifier.height(48.dp),
    )
    val st = c.style(Tool.SHAPES)
    SectionLabel(R.string.opt_color)
    ColorPalette(st.color) { col -> c.updateStyle(Tool.SHAPES) { it.copy(color = col) } }
    SectionLabel(R.string.opt_size)
    Slider(
        value = st.size, valueRange = 1f..24f,
        onValueChange = { v -> c.updateStyle(Tool.SHAPES) { it.copy(size = v) } },
    )
}

/** forSelection != null: التعديل يطبّق على النص المحدد (مع تسجيله في سجل التراجع). */
@Composable
private fun TextControls(c: BoardController, forSelection: TextElement?) {
    val ts = c.textStyle
    val color = forSelection?.color ?: ts.color
    val bold = forSelection?.bold ?: ts.bold
    val italic = forSelection?.italic ?: ts.italic
    val align = forSelection?.align ?: ts.align
    val size = forSelection?.fontSize ?: ts.size

    SectionLabel(R.string.opt_color)
    ColorPalette(color) { col ->
        if (forSelection != null) c.updateSelectedText { it.copy(color = col) }
        else c.textStyle = ts.copy(color = col)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FilterChip(
            selected = bold,
            onClick = { if (forSelection != null) c.updateSelectedText { it.copy(bold = !bold) } else c.textStyle = ts.copy(bold = !bold) },
            label = { Icon(Icons.Rounded.FormatBold, stringResource(R.string.text_bold)) },
            modifier = Modifier.height(48.dp),
        )
        FilterChip(
            selected = italic,
            onClick = { if (forSelection != null) c.updateSelectedText { it.copy(italic = !italic) } else c.textStyle = ts.copy(italic = !italic) },
            label = { Icon(Icons.Rounded.FormatItalic, stringResource(R.string.text_italic)) },
            modifier = Modifier.height(48.dp),
        )
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(
            Triple("start", Icons.Rounded.FormatAlignLeft, R.string.text_align_start),
            Triple("center", Icons.Rounded.FormatAlignCenter, R.string.text_align_center),
            Triple("end", Icons.Rounded.FormatAlignRight, R.string.text_align_end),
        ).forEach { (value, icon, label) ->
            FilterChip(
                selected = align == value,
                onClick = { if (forSelection != null) c.updateSelectedText { it.copy(align = value) } else c.textStyle = ts.copy(align = value) },
                label = { Icon(icon, stringResource(label)) },
                modifier = Modifier.height(48.dp),
            )
        }
    }
    SectionLabel(R.string.opt_size)
    var live by remember(forSelection?.id, size) { mutableFloatStateOf(size) }
    Slider(
        value = live,
        onValueChange = { live = it; if (forSelection == null) c.textStyle = ts.copy(size = it) },
        onValueChangeFinished = { if (forSelection != null) c.updateSelectedText { it.copy(fontSize = live) } },
        valueRange = 14f..120f,
    )
}

@Composable
private fun SectionLabel(res: Int) {
    Text(
        stringResource(res),
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> FlowRowChips(items: List<Pair<T, Int>>, selected: T, onSelect: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEach { (value, label) ->
            FilterChip(
                selected = selected == value,
                onClick = { onSelect(value) },
                label = { Text(stringResource(label), style = MaterialTheme.typography.labelLarge) },
                modifier = Modifier.height(48.dp),
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ColorPalette(selected: Long, onPick: (Long) -> Unit) {
    var showPicker by remember { mutableStateOf(false) }
    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        BoardPalette.colors.forEach { col ->
            val isSel = col == selected
            Box(
                Modifier.size(44.dp).clip44(Color(col))
                    .border(
                        if (isSel) BorderStroke(3.dp, YbpColors.Electric) else BorderStroke(1.dp, Color(0x33808080)),
                        CircleShape,
                    )
                    .clickable { onPick(col) },
            )
        }
        Box(
            Modifier.size(44.dp).border(BorderStroke(1.dp, Color(0x55808080)), CircleShape)
                .clickable { showPicker = true },
            contentAlignment = androidx.compose.ui.Alignment.Center,
        ) { Icon(Icons.Rounded.Add, stringResource(R.string.opt_custom_color)) }
    }
    if (showPicker) {
        ColorPickerDialog(selected, onPick = { onPick(it); showPicker = false }, onDismiss = { showPicker = false })
    }
}

private fun Modifier.clip44(color: Color): Modifier = this.background(color, CircleShape)

/** منتقي لون مخصص (HSV). */
@Composable
fun ColorPickerDialog(initial: Long, onPick: (Long) -> Unit, onDismiss: () -> Unit) {
    val hsv = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(initial.toInt(), it) } }
    var h by remember { mutableFloatStateOf(hsv[0]) }
    var s by remember { mutableFloatStateOf(hsv[1]) }
    var v by remember { mutableFloatStateOf(hsv[2]) }
    val argb = android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.opt_custom_color)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.fillMaxWidth().height(56.dp).background(Color(argb), RoundedCornerShape(12.dp)))
                Text(stringResource(R.string.opt_hue))
                Slider(value = h, onValueChange = { h = it }, valueRange = 0f..360f)
                Text(stringResource(R.string.opt_saturation))
                Slider(value = s, onValueChange = { s = it }, valueRange = 0f..1f)
                Text(stringResource(R.string.opt_brightness))
                Slider(value = v, onValueChange = { v = it }, valueRange = 0f..1f)
            }
        },
        confirmButton = {
            TextButton(onClick = { onPick(argb.toLong() and 0xFFFFFFFFL) }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } },
    )
}
