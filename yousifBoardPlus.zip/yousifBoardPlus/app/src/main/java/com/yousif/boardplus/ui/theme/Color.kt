package com.yousif.boardplus.ui.theme

import androidx.compose.ui.graphics.Color

object YbpColors {
    val Navy = Color(0xFF0B1F4B)
    val NavyDeep = Color(0xFF071536)
    val NavySurface = Color(0xFF12295F)
    val Electric = Color(0xFF2F6BFF)
    val ElectricSoft = Color(0xFFDCE6FF)
    val Ink = Color(0xFF0E1630)
    val Paper = Color(0xFFF6F8FD)
    val Success = Color(0xFF1FB57A)
    val Danger = Color(0xFFE5484D)
}
