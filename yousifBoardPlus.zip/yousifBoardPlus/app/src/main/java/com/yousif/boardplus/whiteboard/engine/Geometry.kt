package com.yousif.boardplus.whiteboard.engine

import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.LruCache
import androidx.compose.ui.geometry.Offset
import com.yousif.boardplus.whiteboard.model.Element
import com.yousif.boardplus.whiteboard.model.ImageElement
import com.yousif.boardplus.whiteboard.model.PdfElement
import com.yousif.boardplus.whiteboard.model.Pt
import com.yousif.boardplus.whiteboard.model.ShapeElement
import com.yousif.boardplus.whiteboard.model.ShapeType
import com.yousif.boardplus.whiteboard.model.Stroke
import com.yousif.boardplus.whiteboard.model.TextElement
import com.yousif.boardplus.whiteboard.model.Transform
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

data class Bounds(val l: Float, val t: Float, val r: Float, val b: Float) {
    val w: Float get() = r - l
    val h: Float get() = b - t
    val cx: Float get() = (l + r) / 2f
    val cy: Float get() = (t + b) / 2f
    fun contains(x: Float, y: Float): Boolean = x >= l && x <= r && y >= t && y <= b
    fun inflate(d: Float): Bounds = Bounds(l - d, t - d, r + d, b + d)
    fun intersects(o: Bounds): Boolean = l <= o.r && o.l <= r && t <= o.b && o.t <= b
}

/** قياس النص عبر StaticLayout: يدعم العربية (تشكيل الحروف واتجاه RTL) تلقائيًا. */
object TextMetrics {
    private val cache = LruCache<String, StaticLayout>(256)

    fun layout(e: TextElement): StaticLayout {
        val key = "${e.fontSize}|${e.bold}|${e.italic}|${e.align}|${e.color}|${e.text}"
        cache.get(key)?.let { return it }
        val style = when {
            e.bold && e.italic -> Typeface.BOLD_ITALIC
            e.bold -> Typeface.BOLD
            e.italic -> Typeface.ITALIC
            else -> Typeface.NORMAL
        }
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = e.fontSize
            color = e.color.toInt()
            typeface = Typeface.create(Typeface.DEFAULT, style)
        }
        val widest = e.text.split('\n').maxOf { paint.measureText(it) }
        val width = ceil(widest).toInt().coerceAtLeast(1) + 2
        val align = when (e.align) {
            "center" -> Layout.Alignment.ALIGN_CENTER
            "end" -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }
        val layout = StaticLayout.Builder.obtain(e.text, 0, e.text.length, paint, width)
            .setAlignment(align)
            .setIncludePad(false)
            .build()
        cache.put(key, layout)
        return layout
    }
}

object Geometry {

    fun localBounds(e: Element): Bounds = when (e) {
        is Stroke -> strokeBounds(e)
        is ShapeElement -> {
            val h = e.strokeWidth / 2f
            Bounds(min(e.x1, e.x2) - h, min(e.y1, e.y2) - h, max(e.x1, e.x2) + h, max(e.y1, e.y2) + h)
        }
        is TextElement -> {
            val l = TextMetrics.layout(e)
            Bounds(e.x, e.y, e.x + l.width, e.y + l.height)
        }
        is ImageElement -> Bounds(e.x, e.y, e.x + e.w, e.y + e.h)
        is PdfElement -> Bounds(e.x, e.y, e.x + e.w, e.y + e.h)
    }

    private fun strokeBounds(s: Stroke): Bounds {
        if (s.points.isEmpty()) return Bounds(0f, 0f, 0f, 0f)
        var l = Float.MAX_VALUE; var t = Float.MAX_VALUE
        var r = -Float.MAX_VALUE; var b = -Float.MAX_VALUE
        for (p in s.points) {
            if (p.x < l) l = p.x
            if (p.x > r) r = p.x
            if (p.y < t) t = p.y
            if (p.y > b) b = p.y
        }
        val h = s.width / 2f
        return Bounds(l - h, t - h, r + h, b + h)
    }

    /** المحيط (pivot) هو مركز الحدود المحلية؛ التحويل: تكبير ثم تدوير حول المركز ثم إزاحة. */
    fun toWorld(e: Element, b: Bounds, x: Float, y: Float): Offset {
        val t = e.transform
        val dx = (x - b.cx) * t.scale
        val dy = (y - b.cy) * t.scale
        val a = Math.toRadians(t.rotation.toDouble())
        val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
        return Offset(b.cx + dx * ca - dy * sa + t.tx, b.cy + dx * sa + dy * ca + t.ty)
    }

    fun toLocal(e: Element, b: Bounds, wx: Float, wy: Float): Offset {
        val t = e.transform
        val ux = wx - b.cx - t.tx
        val uy = wy - b.cy - t.ty
        val a = Math.toRadians(t.rotation.toDouble())
        val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
        val s = if (abs(t.scale) < 1e-4f) 1e-4f else t.scale
        return Offset(b.cx + (ux * ca + uy * sa) / s, b.cy + (-ux * sa + uy * ca) / s)
    }

    fun worldCorners(e: Element, b: Bounds = localBounds(e)): List<Offset> = listOf(
        toWorld(e, b, b.l, b.t), toWorld(e, b, b.r, b.t),
        toWorld(e, b, b.r, b.b), toWorld(e, b, b.l, b.b),
    )

    fun worldBounds(e: Element, b: Bounds = localBounds(e)): Bounds {
        val c = worldCorners(e, b)
        return Bounds(c.minOf { it.x }, c.minOf { it.y }, c.maxOf { it.x }, c.maxOf { it.y })
    }

    fun worldCenter(e: Element, b: Bounds = localBounds(e)): Offset =
        Offset(b.cx + e.transform.tx, b.cy + e.transform.ty)

    fun resizeHandle(e: Element): Offset = worldCorners(e)[2]

    fun rotateHandle(e: Element, distance: Float): Offset {
        val b = localBounds(e)
        val top = toWorld(e, b, b.cx, b.t)
        val ctr = worldCenter(e, b)
        val dx = top.x - ctr.x; val dy = top.y - ctr.y
        val len = hypot(dx, dy)
        return if (len < 1e-3f) Offset(top.x, top.y - distance)
        else Offset(top.x + dx / len * distance, top.y + dy / len * distance)
    }

    /** يدمج التحويل في نقاط الخط (مطلوب قبل المسح بالبكسل حتى لا يتحرك محور الدوران). */
    fun bake(s: Stroke): Stroke {
        val b = strokeBounds(s)
        val pts = s.points.map { p ->
            val w = toWorld(s, b, p.x, p.y)
            Pt(w.x, w.y, p.p)
        }
        return s.copy(points = pts, width = s.width * s.transform.scale, transform = Transform())
    }

    fun hit(e: Element, wx: Float, wy: Float, tolWorld: Float): Boolean {
        val b = localBounds(e)
        val p = toLocal(e, b, wx, wy)
        val tol = tolWorld / max(e.transform.scale, 1e-3f)
        if (!b.inflate(tol).contains(p.x, p.y)) return false
        return when (e) {
            is Stroke -> strokeHit(e, p, tol)
            is ShapeElement -> shapeHit(e, p, tol)
            else -> true
        }
    }

    private fun strokeHit(s: Stroke, p: Offset, tol: Float): Boolean {
        val r = s.width / 2f + tol
        val pts = s.points
        if (pts.isEmpty()) return false
        if (pts.size == 1) return hypot(p.x - pts[0].x, p.y - pts[0].y) <= r
        for (i in 1 until pts.size) {
            if (distToSegment(p.x, p.y, pts[i - 1].x, pts[i - 1].y, pts[i].x, pts[i].y) <= r) return true
        }
        return false
    }

    private fun shapeHit(s: ShapeElement, p: Offset, tol: Float): Boolean {
        val l = min(s.x1, s.x2); val r = max(s.x1, s.x2)
        val t = min(s.y1, s.y2); val bt = max(s.y1, s.y2)
        val half = s.strokeWidth / 2f + tol
        when (s.shape) {
            ShapeType.LINE, ShapeType.ARROW ->
                return distToSegment(p.x, p.y, s.x1, s.y1, s.x2, s.y2) <= half
            ShapeType.CIRCLE, ShapeType.ELLIPSE -> {
                var a = (r - l) / 2f; var b = (bt - t) / 2f
                if (s.shape == ShapeType.CIRCLE) { val m = min(a, b); a = m; b = m }
                if (a <= 0.5f || b <= 0.5f) return true
                val d = hypot((p.x - (l + r) / 2f) / a, (p.y - (t + bt) / 2f) / b)
                val k = half / min(a, b)
                return if (s.fillColor != null) d <= 1f + k else abs(d - 1f) <= k
            }
            else -> {
                val outer = Bounds(l, t, r, bt).inflate(half)
                if (!outer.contains(p.x, p.y)) return false
                if (s.fillColor != null) return true
                val inner = Bounds(l, t, r, bt).inflate(-half)
                return !inner.contains(p.x, p.y)
            }
        }
    }

    fun distToSegment(px: Float, py: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
        val dx = x2 - x1; val dy = y2 - y1
        val len2 = dx * dx + dy * dy
        if (len2 < 1e-6f) return hypot(px - x1, py - y1)
        val t = (((px - x1) * dx + (py - y1) * dy) / len2).coerceIn(0f, 1f)
        return hypot(px - (x1 + t * dx), py - (y1 + t * dy))
    }
}
