package com.yousif.boardplus.whiteboard.engine

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Path
import com.yousif.boardplus.whiteboard.model.ShapeElement
import com.yousif.boardplus.whiteboard.model.ShapeType
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

object ShapePaths {

    fun isClosed(t: ShapeType) = t != ShapeType.LINE && t != ShapeType.ARROW

    fun build(s: ShapeElement): Path {
        val p = Path()
        val l = min(s.x1, s.x2); val r = max(s.x1, s.x2)
        val t = min(s.y1, s.y2); val b = max(s.y1, s.y2)
        val cx = (l + r) / 2f; val cy = (t + b) / 2f
        val a = (r - l) / 2f; val h = (b - t) / 2f
        when (s.shape) {
            ShapeType.LINE -> { p.moveTo(s.x1, s.y1); p.lineTo(s.x2, s.y2) }
            ShapeType.ARROW -> {
                p.moveTo(s.x1, s.y1); p.lineTo(s.x2, s.y2)
                val ang = atan2(s.y2 - s.y1, s.x2 - s.x1)
                val len = hypot(s.x2 - s.x1, s.y2 - s.y1)
                val head = min(max(16f, s.strokeWidth * 4f), len * 0.5f)
                for (da in floatArrayOf(0.5f, -0.5f)) {
                    p.moveTo(s.x2, s.y2)
                    p.lineTo(s.x2 - head * cos(ang + da), s.y2 - head * sin(ang + da))
                }
            }
            ShapeType.RECTANGLE -> p.addRect(Rect(l, t, r, b))
            ShapeType.ROUNDED_RECT -> {
                val rad = min(r - l, b - t) * 0.18f
                p.addRoundRect(RoundRect(l, t, r, b, rad, rad))
            }
            ShapeType.CIRCLE -> p.addOval(Rect(Offset(cx, cy), min(a, h)))
            ShapeType.ELLIPSE -> p.addOval(Rect(l, t, r, b))
            ShapeType.TRIANGLE -> {
                p.moveTo(cx, t); p.lineTo(r, b); p.lineTo(l, b); p.close()
            }
            ShapeType.POLYGON -> {
                val n = s.sides.coerceAtLeast(3)
                for (k in 0 until n) {
                    val ang = -PI / 2.0 + 2.0 * PI * k / n
                    val x = cx + a * cos(ang).toFloat(); val y = cy + h * sin(ang).toFloat()
                    if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
            ShapeType.STAR -> {
                val points = 5
                for (k in 0 until points * 2) {
                    val ang = -PI / 2.0 + PI * k / points
                    val f = if (k % 2 == 0) 1f else 0.42f
                    val x = cx + a * f * cos(ang).toFloat(); val y = cy + h * f * sin(ang).toFloat()
                    if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                p.close()
            }
        }
        return p
    }

    /** Snap ذكي: خطوط/أسهم تلتصق بزوايا 45°، والمستطيل/البيضاوي يتحول لمربع/دائرة عند التقارب. */
    fun snapEnd(type: ShapeType, x1: Float, y1: Float, x2: Float, y2: Float): Offset {
        val dx = x2 - x1; val dy = y2 - y1
        return when (type) {
            ShapeType.LINE, ShapeType.ARROW -> {
                val len = hypot(dx, dy)
                if (len < 1f) return Offset(x2, y2)
                val ang = atan2(dy, dx)
                val step = (PI / 4.0).toFloat()
                val nearest = (ang / step).roundToInt() * step
                if (abs(ang - nearest) < 0.0873f) // ≈ 5°
                    Offset(x1 + len * cos(nearest), y1 + len * sin(nearest))
                else Offset(x2, y2)
            }
            ShapeType.RECTANGLE, ShapeType.ROUNDED_RECT, ShapeType.ELLIPSE -> {
                val aw = abs(dx); val ah = abs(dy)
                val m = max(aw, ah)
                if (m > 10f && abs(aw - ah) / m < 0.08f) {
                    val side = min(aw, ah)
                    Offset(x1 + if (dx >= 0) side else -side, y1 + if (dy >= 0) side else -side)
                } else Offset(x2, y2)
            }
            else -> Offset(x2, y2)
        }
    }
}
