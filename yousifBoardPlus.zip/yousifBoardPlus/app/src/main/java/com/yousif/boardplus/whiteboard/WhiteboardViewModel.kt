package com.yousif.boardplus.whiteboard

import androidx.lifecycle.ViewModel
import com.yousif.boardplus.whiteboard.engine.BoardController
import com.yousif.boardplus.whiteboard.engine.newId
import com.yousif.boardplus.whiteboard.model.WhiteboardDocument
import com.yousif.boardplus.whiteboard.model.WhiteboardPage

/** يحتفظ بالسبورة أثناء تدوير الشاشة. الحفظ والاستعادة تُضاف في المرحلة 7. */
class WhiteboardViewModel : ViewModel() {
    val board = BoardController(newDocument())

    companion object {
        fun newDocument(): WhiteboardDocument {
            val now = System.currentTimeMillis()
            return WhiteboardDocument(
                id = newId(), title = "", createdAt = now, updatedAt = now,
                pages = listOf(WhiteboardPage(id = newId(), name = "1")),
            )
        }
    }
}
