package com.yousif.boardplus.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FlashOn
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.PermMedia
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Slideshow
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.yousif.boardplus.R
import com.yousif.boardplus.navigation.Routes
import com.yousif.boardplus.ui.theme.YbpColors

private data class DashItem(
    val route: String,
    val titleRes: Int,
    val icon: ImageVector,
    val accent: Color = YbpColors.Electric,
)

private val items = listOf(
    DashItem(Routes.LESSONS, R.string.dash_my_lessons, Icons.Rounded.MenuBook),
    DashItem(Routes.RECENT, R.string.dash_recent, Icons.Rounded.History),
    DashItem(Routes.PDF, R.string.dash_pdf, Icons.Rounded.PictureAsPdf),
    DashItem(Routes.PRESENTATIONS, R.string.dash_presentations, Icons.Rounded.Slideshow),
    DashItem(Routes.MEDIA, R.string.dash_media, Icons.Rounded.PermMedia),
    DashItem(Routes.AI, R.string.dash_ai, Icons.Rounded.AutoAwesome),
    DashItem(Routes.SETTINGS, R.string.dash_settings, Icons.Rounded.Settings),
)

/** لوحة التحكم: عدد الأعمدة يتكيف مع عرض الشاشة (هاتف/تابلت/سبورة 55–86 بوصة). */
@Composable
fun DashboardScreen(onNavigate: (String) -> Unit) {
    BoxWithConstraints(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).systemBarsPadding()
    ) {
        val columns = when {
            maxWidth >= 1200.dp -> 5
            maxWidth >= 840.dp -> 4
            maxWidth >= 600.dp -> 3
            else -> 2
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(columns),
            contentPadding = PaddingValues(24.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) { Header() }
            item(span = { GridItemSpan(maxLineSpan) }) {
                HeroCard(onNew = { onNavigate(Routes.WHITEBOARD) })
            }
            items(items) { item -> DashCard(item) { onNavigate(item.route) } }
        }
    }
}

@Composable
private fun Header() {
    Column(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
        Text(
            stringResource(R.string.app_name),
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            stringResource(R.string.dash_greeting),
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun HeroCard(onNew: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = YbpColors.Electric,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 140.dp)
            .clickable(role = Role.Button, onClick = onNew),
    ) {
        Row(Modifier.padding(28.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Edit, null, tint = Color.White, modifier = Modifier.size(56.dp))
            Spacer(Modifier.width(20.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.dash_new_whiteboard),
                    style = MaterialTheme.typography.headlineMedium, color = Color.White,
                )
                Text(
                    stringResource(R.string.dash_new_whiteboard_sub),
                    style = MaterialTheme.typography.bodyLarge, color = Color.White.copy(alpha = 0.85f),
                )
            }
            Icon(Icons.Rounded.FlashOn, null, tint = Color.White, modifier = Modifier.size(32.dp))
        }
    }
}

@Composable
private fun DashCard(item: DashItem, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 140.dp)
            .clickable(role = Role.Button, onClick = onClick),
    ) {
        Column(
            Modifier.padding(20.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Icon(item.icon, null, tint = item.accent, modifier = Modifier.size(44.dp))
            Spacer(Modifier.size(20.dp))
            Text(
                stringResource(item.titleRes),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}
