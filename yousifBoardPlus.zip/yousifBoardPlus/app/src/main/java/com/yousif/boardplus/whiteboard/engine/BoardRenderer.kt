package com.yousif.boardplus.whiteboard.engine

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import com.yousif.boardplus.whiteboard.model.BoardBackground
import com.yousif.boardplus.whiteboard.model.Element
import com.yousif.boardplus.whiteboard.model.ImageElement
import com.yousif.boardplus.whiteboard.model.PdfElement
import com.yousif.boardplus.whiteboard.model.ShapeElement
import com.yousif.boardplus.whiteboard.model.Stroke
import com.yousif.boardplus.whiteboard.model.TextElement
import kotlin.math.floor
import kotlin.math.max
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke

/** ذاكرة مؤقتة للمسارات والحدود: الخط الذي لم يتغير لا يُعاد بناؤه عند كل إطار. */
class StrokeCache {
    private class Entry(val src: Stroke, val path: Path, val bounds: Bounds)

    private val map = HashMap<String, Entry>()

    private fun entry(s: Stroke): Entry {
        val c = map[s.id]
        if (c != null && c.src.points === s.points && c.src.width == s.width && c.src.pen == s.pen) return c
        val e = Entry(s, StrokeOutline.build(s.pen, s.width, s.points), Geometry.localBounds(s))
        map[s.id] = e
        return e
    }

    fun path(s: Stroke): Path = entry(s).path
    fun bounds(e: Element): Bounds = if (e is Stroke) entry(e).bounds else Geometry.localBounds(e)
    fun retainOnly(ids: Set<String>) { map.keys.retainAll(ids) }
}

/** المنطقة المرئية من السبورة بإحداثيات العالم. */
fun visibleWorldRect(size: androidx.compose.ui.geometry.Size, offset: Offset, scale: Float): Rect =
    Rect(-offset.x / scale, -offset.y / scale, (size.width - offset.x) / scale, (size.height - offset.y) / scale)

fun DrawScope.drawBoardBackground(bg: BoardBackground, vis: Rect, scale: Float) {
    val dark = bg == BoardBackground.BLACK
    drawRect(if (dark) Color(0xFF111417) else Color.White, vis.topLeft, vis.size)
    val hair = 1f / scale
    when (bg) {
        BoardBackground.GRID -> gridLines(vis, 50f, Color(0xFFD5DCE8), hair)
        BoardBackground.MATH_GRID -> {
            gridLines(vis, 25f, Color(0xFFE3E8F1), hair)
            gridLines(vis, 125f, Color(0xFFB4C0D4), hair * 1.6f)
        }
        BoardBackground.DOTS -> dotGrid(vis, 50f, Color(0xFF9AA7BD), max(2f, 1.3f * hair))
        BoardBackground.NOTEBOOK -> {
            var step = 44f
            while (vis.height / step > 300f) step *= 2f
            var y = floor(vis.top / step) * step
            while (y <= vis.bottom) {
                drawLine(Color(0xFFC9D6EC), Offset(vis.left, y), Offset(vis.right, y), hair * 1.2f)
                y += step
            }
            if (110f in vis.left..vis.right)
                drawLine(Color(0xFFF3A6A6), Offset(110f, vis.top), Offset(110f, vis.bottom), hair * 2f)
        }
        else -> Unit
    }
}

private fun DrawScope.gridLines(vis: Rect, step0: Float, color: Color, w: Float) {
    var step = step0
    while (max(vis.width, vis.height) / step > 300f) step *= 2f
    var x = floor(vis.left / step) * step
    while (x <= vis.right) { drawLine(color, Offset(x, vis.top), Offset(x, vis.bottom), w); x += step }
    var y = floor(vis.top / step) * step
    while (y <= vis.bottom) { drawLine(color, Offset(vis.left, y), Offset(vis.right, y), w); y += step }
}

private fun DrawScope.dotGrid(vis: Rect, step0: Float, color: Color, radius: Float) {
    var step = step0
    while ((vis.width / step) * (vis.height / step) > 20000f) step *= 2f
    var x = floor(vis.left / step) * step
    while (x <= vis.right) {
        var y = floor(vis.top / step) * step
        while (y <= vis.bottom) { drawCircle(color, radius, Offset(x, y)); y += step }
        x += step
    }
}

/** يرسم عنصرًا مع تحويله. الرسم متجهي بالكامل فلا تفقد الخطوط جودتها عند التكبير. */
fun DrawScope.drawBoardElement(e: Element, cache: StrokeCache) {
    val t = e.transform
    val b = cache.bounds(e)
    val identity = t.tx == 0f && t.ty == 0f && t.scale == 1f && t.rotation == 0f
    if (identity) {
        drawElementLocal(e, cache)
    } else {
        val c = Offset(b.cx, b.cy)
        withTransform({
            translate(t.tx, t.ty)
            rotate(t.rotation, c)
            scale(t.scale, t.scale, c)
        }) { drawElementLocal(e, cache) }
    }
}

private fun DrawScope.drawElementLocal(e: Element, cache: StrokeCache) {
    when (e) {
        is Stroke -> drawPath(
            cache.path(e),
            Color(e.color).copy(alpha = (e.opacity * StrokeOutline.penAlpha(e.pen)).coerceIn(0f, 1f)),
        )
        is ShapeElement -> {
            val p = ShapePaths.build(e)
            e.fillColor?.let { if (ShapePaths.isClosed(e.shape)) drawPath(p, Color(it)) }
            drawPath(
                p, Color(e.color),
                style = DrawStroke(width = e.strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
        }
        is TextElement -> {
            val layout = TextMetrics.layout(e)
            drawIntoCanvas { canvas ->
                val nc = canvas.nativeCanvas
                nc.save()
                nc.translate(e.x, e.y)
                layout.draw(nc)
                nc.restore()
            }
        }
        // الصور وPDF تُرسم في المرحلة 8 (تحميل كسول للـ Bitmaps)
        is ImageElement, is PdfElement -> Unit
    }
}
