package com.yousif.boardplus.whiteboard.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke as DrawStroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.pointerInput
import com.yousif.boardplus.ui.theme.YbpColors
import com.yousif.boardplus.whiteboard.engine.BoardController
import com.yousif.boardplus.whiteboard.engine.Geometry
import com.yousif.boardplus.whiteboard.engine.ShapePaths
import com.yousif.boardplus.whiteboard.engine.StrokeCache
import com.yousif.boardplus.whiteboard.engine.StrokeOutline
import com.yousif.boardplus.whiteboard.engine.drawBoardBackground
import com.yousif.boardplus.whiteboard.engine.drawBoardElement
import com.yousif.boardplus.whiteboard.engine.visibleWorldRect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin

/**
 * طبقتان منفصلتان:
 *  1) المحتوى المثبّت (خلفية + عناصر) — لا يُعاد رسمه أثناء حركة القلم.
 *  2) الطبقة الحية (الخط الجاري، المعاينة، التحديد، مؤشر الممحاة).
 */
@Composable
fun BoardCanvas(c: BoardController, modifier: Modifier = Modifier) {
    val cache = remember { StrokeCache() }

    LaunchedEffect(c.revision) {
        cache.retainOnly(c.elements.mapTo(HashSet()) { it.id })
    }

    Box(modifier.clipToBounds().pointerInput(c) { boardGestures(c) }) {
        Canvas(Modifier.fillMaxSize()) {
            val scale = c.viewScale
            val off = c.viewOffset
            val vis = visibleWorldRect(size, off, scale)
            withTransform({
                translate(off.x, off.y)
                scale(scale, scale, Offset.Zero)
            }) {
                drawBoardBackground(c.page.background, vis, scale)
                val visB = com.yousif.boardplus.whiteboard.engine.Bounds(vis.left, vis.top, vis.right, vis.bottom)
                for (e in c.elements) {
                    val lb = cache.bounds(e)
                    if (Geometry.worldBounds(e, lb).intersects(visB)) drawBoardElement(e, cache)
                }
            }
        }

        Canvas(Modifier.fillMaxSize()) {
            c.liveVersion // اشتراك في تغيّر الخط الحي
            val scale = c.viewScale
            val off = c.viewOffset
            withTransform({
                translate(off.x, off.y)
                scale(scale, scale, Offset.Zero)
            }) {
                c.liveStroke()?.let { s ->
                    drawPath(
                        StrokeOutline.build(s.pen, s.width, s.points),
                        Color(s.color).copy(alpha = (s.opacity * StrokeOutline.penAlpha(s.pen)).coerceIn(0f, 1f)),
                    )
                }
                c.liveShape?.let { sh ->
                    val p = ShapePaths.build(sh)
                    sh.fillColor?.let { drawPath(p, Color(it)) }
                    drawPath(p, Color(sh.color), style = DrawStroke(sh.strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
                drawSelection(c, scale)
                c.areaRect?.let { r ->
                    drawRect(
                        YbpColors.Danger.copy(alpha = 0.12f), r.topLeft, r.size,
                    )
                    drawRect(
                        YbpColors.Danger, r.topLeft, r.size,
                        style = DrawStroke(2f / scale, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f / scale, 8f / scale))),
                    )
                }
                c.cursorWorld?.let { cur ->
                    if (c.areaRect == null)
                        drawCircle(Color(0xFF888888), c.eraserSize / scale / 2f, cur, style = DrawStroke(1.5f / scale))
                }
            }
        }
    }
}

private fun DrawScope.drawSelection(c: BoardController, scale: Float) {
    val sel = c.selected ?: return
    val corners = Geometry.worldCorners(sel)
    val outline = Path().apply {
        moveTo(corners[0].x, corners[0].y)
        for (i in 1..3) lineTo(corners[i].x, corners[i].y)
        close()
    }
    drawPath(
        outline, YbpColors.Electric,
        style = DrawStroke(2f / scale, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f / scale, 8f / scale))),
    )
    val r = 13f / scale
    val resize = Geometry.resizeHandle(sel)
    val rotate = Geometry.rotateHandle(sel, 44f / scale)
    val top = Geometry.toWorld(sel, Geometry.localBounds(sel), Geometry.localBounds(sel).cx, Geometry.localBounds(sel).t)
    drawLine(YbpColors.Electric, top, rotate, 2f / scale)
    for (h in listOf(resize, rotate)) {
        drawCircle(Color.White, r, h)
        drawCircle(YbpColors.Electric, r, h, style = DrawStroke(3f / scale))
    }
}
