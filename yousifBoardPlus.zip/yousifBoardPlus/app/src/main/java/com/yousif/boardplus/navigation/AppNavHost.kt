package com.yousif.boardplus.navigation

import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.yousif.boardplus.R
import com.yousif.boardplus.ui.dashboard.DashboardScreen
import com.yousif.boardplus.ui.splash.SplashScreen
import com.yousif.boardplus.whiteboard.ui.WhiteboardScreen

@Composable
fun AppNavHost(navController: NavHostController = rememberNavController()) {
    val context = LocalContext.current
    val notReady = stringResource(R.string.coming_soon)

    /** يتنقل فقط إلى مسار مسجّل؛ المسارات غير الجاهزة بعد لا تُسقط التطبيق. */
    val safeNavigate: (String) -> Unit = { route ->
        val registered = navController.graph.findNode(route) != null
        if (registered) navController.navigate(route)
        else Toast.makeText(context, notReady, Toast.LENGTH_SHORT).show()
    }

    NavHost(navController = navController, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen(onFinished = {
                navController.navigate(Routes.DASHBOARD) {
                    popUpTo(Routes.SPLASH) { inclusive = true }
                }
            })
        }
        composable(Routes.DASHBOARD) {
            DashboardScreen(onNavigate = safeNavigate)
        }
        composable(Routes.WHITEBOARD) {
            WhiteboardScreen(onExit = { navController.popBackStack() })
        }
        // المراحل 7+: الدروس، PDF، الوسائط، الذكاء الاصطناعي، الإعدادات
    }
}
