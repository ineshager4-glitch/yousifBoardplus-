package com.yousif.boardplus.navigation

/** كل مسارات التطبيق في مكان واحد. تُسجَّل شاشاتها تدريجيًا حسب المراحل. */
object Routes {
    const val SPLASH = "splash"
    const val DASHBOARD = "dashboard"
    const val WHITEBOARD = "whiteboard"
    const val LESSONS = "lessons"
    const val RECENT = "recent"
    const val PDF = "pdf"
    const val PRESENTATIONS = "presentations"
    const val MEDIA = "media"
    const val AI = "ai"
    const val SETTINGS = "settings"
}
