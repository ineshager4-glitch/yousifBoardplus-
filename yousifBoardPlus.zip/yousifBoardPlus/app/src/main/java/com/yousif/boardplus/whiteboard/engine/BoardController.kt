package com.yousif.boardplus.whiteboard.engine

import android.os.SystemClock
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import com.yousif.boardplus.whiteboard.history.Edit
import com.yousif.boardplus.whiteboard.history.EditHistory
import com.yousif.boardplus.whiteboard.history.diffEdit
import com.yousif.boardplus.whiteboard.model.BoardBackground
import com.yousif.boardplus.whiteboard.model.Element
import com.yousif.boardplus.whiteboard.model.PenType
import com.yousif.boardplus.whiteboard.model.Pt
import com.yousif.boardplus.whiteboard.model.ShapeElement
import com.yousif.boardplus.whiteboard.model.ShapeType
import com.yousif.boardplus.whiteboard.model.Stroke
import com.yousif.boardplus.whiteboard.model.TextElement
import com.yousif.boardplus.whiteboard.model.Transform
import com.yousif.boardplus.whiteboard.model.WhiteboardDocument
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * قلب السبورة: الحالة + منطق الأدوات + السجل. كل الإدخال يصل عبر
 * begin/move/endInteraction بإحداثيات الشاشة، والتحويل إلى إحداثيات العالم يتم هنا.
 */
@Stable
class BoardController(initial: WhiteboardDocument) {

    // ───────── المستند ─────────
    var document by mutableStateOf(initial); private set
    var pageIndex by mutableIntStateOf(0); private set
    /** يزداد مع كل تعديل مثبّت؛ يعتمد عليه الحفظ التلقائي (المرحلة 7). */
    var revision by mutableIntStateOf(0); private set

    val page get() = document.pages[pageIndex]
    val elements: List<Element> get() = page.elements

    // ───────── الأدوات ─────────
    var tool by mutableStateOf(Tool.PEN); private set
    var penType by mutableStateOf(PenType.PEN)
    var shapeType by mutableStateOf(ShapeType.RECTANGLE)
    var shapeFill by mutableStateOf(false)
    var eraserMode by mutableStateOf(EraserMode.PIXEL)
    var eraserSize by mutableFloatStateOf(44f) // قطر بالبكسل على الشاشة
    var textStyle by mutableStateOf(TextStyleState())
    var palmRejection by mutableStateOf(true)

    val styles = mutableStateMapOf(
        Tool.PEN to ToolStyle(0xFF000000, 4f, 1f),
        Tool.MARKER to ToolStyle(0xFF2F6BFF, 10f, 1f),
        Tool.HIGHLIGHTER to ToolStyle(0xFFFFD60A, 28f, 0.35f),
        Tool.SHAPES to ToolStyle(0xFF2F6BFF, 4f, 1f),
    )

    fun style(t: Tool = tool): ToolStyle = styles[t] ?: ToolStyle(0xFF000000, 4f, 1f)
    fun updateStyle(t: Tool, f: (ToolStyle) -> ToolStyle) { styles[t] = f(style(t)) }

    fun selectTool(t: Tool) {
        if (t != Tool.SELECT) selectedId = null
        tool = t
    }

    // ───────── العرض (Zoom / Pan) ─────────
    var viewScale by mutableFloatStateOf(1f); private set
    var viewOffset by mutableStateOf(Offset.Zero); private set

    private fun toWorldPt(s: Offset) = Offset((s.x - viewOffset.x) / viewScale, (s.y - viewOffset.y) / viewScale)

    fun transformView(newCentroid: Offset, oldCentroid: Offset, zoom: Float) {
        val w = toWorldPt(oldCentroid)
        val ns = (viewScale * zoom).coerceIn(0.1f, 8f)
        viewScale = ns
        viewOffset = Offset(newCentroid.x - w.x * ns, newCentroid.y - w.y * ns)
    }

    fun zoomAround(screen: Offset, zoom: Float) = transformView(screen, screen, zoom)
    fun resetView() { viewScale = 1f; viewOffset = Offset.Zero }

    // ───────── التحديد والحافظة ─────────
    var selectedId by mutableStateOf<String?>(null); private set
    val selected: Element? get() = selectedId?.let { id -> elements.firstOrNull { it.id == id } }
    private var clipboard: Element? = null
    var hasClipboard by mutableStateOf(false); private set
    var textEdit by mutableStateOf<TextEditRequest?>(null); private set

    fun deselect() { selectedId = null }

    // ───────── السجل ─────────
    private val histories = HashMap<String, EditHistory>()
    var canUndo by mutableStateOf(false); private set
    var canRedo by mutableStateOf(false); private set

    private fun history() = histories.getOrPut(page.id) { EditHistory() }
    private fun refreshFlags() { canUndo = history().canUndo; canRedo = history().canRedo }

    private fun setElements(list: List<Element>) {
        document = document.copy(
            pages = document.pages.mapIndexed { i, p -> if (i == pageIndex) p.copy(elements = list) else p },
            updatedAt = System.currentTimeMillis(),
        )
        revision++
    }

    private fun commit(edit: Edit) {
        setElements(edit.apply(elements))
        history().record(edit)
        refreshFlags()
    }

    fun undo() {
        val r = history().undo(elements) ?: return
        setElements(r); fixSelection(); refreshFlags()
    }

    fun redo() {
        val r = history().redo(elements) ?: return
        setElements(r); fixSelection(); refreshFlags()
    }

    private fun fixSelection() { if (selected == null) selectedId = null }

    private fun replaceElement(n: Element) = setElements(elements.map { if (it.id == n.id) n else it })

    private fun insert(e: Element) = commit(Edit.Insert(listOf(elements.size to e)))

    fun setBackground(bg: BoardBackground) {
        document = document.copy(
            pages = document.pages.mapIndexed { i, p -> if (i == pageIndex) p.copy(background = bg) else p },
            updatedAt = System.currentTimeMillis(),
        )
        revision++
        // لا نترك قلمًا أسود على سبورة سوداء
        if (bg == BoardBackground.BLACK) {
            for (t in listOf(Tool.PEN, Tool.MARKER, Tool.SHAPES)) {
                if (style(t).color == 0xFF000000) updateStyle(t) { it.copy(color = 0xFFFFFFFF) }
            }
            if (textStyle.color == 0xFF000000) textStyle = textStyle.copy(color = 0xFFFFFFFF)
        }
    }

    fun clearPage() {
        if (elements.isEmpty()) return
        selectedId = null
        commit(Edit.Delete(elements.withIndex().map { it.index to it.value }))
    }

    // ───────── إجراءات العنصر المحدد ─────────
    fun deleteSelected() {
        val s = selected ?: return
        val idx = elements.indexOfFirst { it.id == s.id }
        selectedId = null
        commit(Edit.Delete(listOf(idx to s)))
    }

    fun duplicateSelected() {
        val s = selected ?: return
        val t = s.transform
        val copy = s.withId(newId()).withTransform(t.copy(tx = t.tx + 40f, ty = t.ty + 40f))
        insert(copy)
        selectedId = copy.id
    }

    fun copySelected() { clipboard = selected; hasClipboard = clipboard != null }

    fun paste() {
        val c = clipboard ?: return
        val t = c.transform
        val n = c.withId(newId()).withTransform(t.copy(tx = t.tx + 40f, ty = t.ty + 40f))
        clipboard = n
        insert(n)
        tool = Tool.SELECT
        selectedId = n.id
    }

    fun rotateSelected(deg: Float) {
        val s = selected ?: return
        commit(Edit.Update(listOf(s), listOf(s.withTransform(s.transform.copy(rotation = s.transform.rotation + deg)))))
    }

    fun scaleSelected(factor: Float) {
        val s = selected ?: return
        val ns = (s.transform.scale * factor).coerceIn(0.05f, 40f)
        commit(Edit.Update(listOf(s), listOf(s.withTransform(s.transform.copy(scale = ns)))))
    }

    fun editSelectedText() {
        val s = selected as? TextElement ?: return
        textEdit = TextEditRequest(Offset(s.x, s.y), s)
    }

    fun updateSelectedText(f: (TextElement) -> TextElement) {
        val s = selected as? TextElement ?: return
        commit(Edit.Update(listOf(s), listOf(f(s))))
    }

    // ───────── النص ─────────
    fun dismissText() { textEdit = null }

    fun confirmText(text: String) {
        val req = textEdit ?: return
        textEdit = null
        val old = req.existing
        if (old != null) {
            if (text.isBlank()) {
                val idx = elements.indexOfFirst { it.id == old.id }
                if (idx >= 0) { selectedId = null; commit(Edit.Delete(listOf(idx to old))) }
            } else if (text != old.text) {
                commit(Edit.Update(listOf(old), listOf(old.copy(text = text))))
            }
            return
        }
        if (text.isBlank()) return
        val ts = textStyle
        insert(
            TextElement(
                id = newId(), text = text, x = req.pos.x, y = req.pos.y,
                fontSize = ts.size, bold = ts.bold, italic = ts.italic, align = ts.align, color = ts.color,
            )
        )
    }

    // ───────── Palm rejection ─────────
    private var lastStylusAt = -100_000L
    fun noteStylus() { lastStylusAt = SystemClock.uptimeMillis() }
    fun fingerCanDraw(): Boolean = !(palmRejection && SystemClock.uptimeMillis() - lastStylusAt < 4000L)

    // ───────── التفاعل الحي ─────────
    private enum class Drag { NONE, STROKE, ERASE, AREA, SHAPE, MOVE, RESIZE, ROTATE, PAN, TEXT_TAP }

    private var drag = Drag.NONE
    private var moved = false
    private var startWorld = Offset.Zero
    private var lastWorld = Offset.Zero
    private var lastScreen = Offset.Zero
    private var sessionStart: List<Element> = emptyList()
    private var dragOriginal: Element? = null
    private var startAngle = 0f
    private var startDist = 1f
    private var activeTool = Tool.PEN

    private val livePts = ArrayList<Pt>()
    /** يتغير مع كل نقطة؛ طبقة الرسم الحي تقرأه فتُعاد رسمها وحدها دون المحتوى المثبّت. */
    var liveVersion by mutableIntStateOf(0); private set
    var liveShape by mutableStateOf<ShapeElement?>(null); private set
    var cursorWorld by mutableStateOf<Offset?>(null); private set
    var areaRect by mutableStateOf<Rect?>(null); private set

    fun liveStroke(): Stroke? {
        if (drag != Drag.STROKE || livePts.isEmpty()) return null
        val st = style(activeTool)
        return Stroke("live", penFor(activeTool), st.color, st.size, st.opacity, livePts)
    }

    private fun penFor(t: Tool) = when (t) {
        Tool.PEN -> penType
        Tool.MARKER -> PenType.MARKER
        Tool.HIGHLIGHTER -> PenType.HIGHLIGHTER
        else -> PenType.PEN
    }

    fun beginPan(screen: Offset) { drag = Drag.PAN; lastScreen = screen }

    fun beginInteraction(screen: Offset, pressure: Float, eraserEnd: Boolean) {
        val p = toWorldPt(screen)
        startWorld = p; lastWorld = p; lastScreen = screen; moved = false
        activeTool = if (eraserEnd) Tool.ERASER else tool
        when (activeTool) {
            Tool.PEN, Tool.MARKER, Tool.HIGHLIGHTER -> {
                livePts.clear(); livePts.add(Pt(p.x, p.y, pressure))
                drag = Drag.STROKE; liveVersion++
            }
            Tool.ERASER -> {
                sessionStart = elements
                cursorWorld = p
                if (eraserMode == EraserMode.AREA) { drag = Drag.AREA; areaRect = Rect(p, p) }
                else { drag = Drag.ERASE; eraseAt(p) }
            }
            Tool.SHAPES -> { drag = Drag.SHAPE; updateLiveShape(p) }
            Tool.TEXT -> drag = Drag.TEXT_TAP
            Tool.SELECT -> beginSelect(screen, p)
        }
    }

    fun moveInteraction(screen: Offset, pressure: Float) {
        if (drag == Drag.PAN) {
            viewOffset += screen - lastScreen
            lastScreen = screen
            return
        }
        val p = toWorldPt(screen)
        lastWorld = p
        when (drag) {
            Drag.STROKE -> {
                val last = livePts.last()
                if (hypot(p.x - last.x, p.y - last.y) < 0.8f / viewScale) return
                val a = 0.65f // تنعيم الإدخال
                livePts.add(Pt(last.x + (p.x - last.x) * a, last.y + (p.y - last.y) * a, last.p * 0.5f + pressure * 0.5f))
                liveVersion++
            }
            Drag.ERASE -> { cursorWorld = p; eraseAt(p) }
            Drag.AREA -> {
                cursorWorld = p
                areaRect = Rect(min(startWorld.x, p.x), min(startWorld.y, p.y), max(startWorld.x, p.x), max(startWorld.y, p.y))
            }
            Drag.SHAPE -> updateLiveShape(p)
            Drag.TEXT_TAP -> if ((p - startWorld).getDistance() > 8f / viewScale) moved = true
            Drag.MOVE, Drag.RESIZE, Drag.ROTATE -> dragSelection(p)
            else -> Unit
        }
    }

    fun endInteraction() {
        when (drag) {
            Drag.STROKE -> commitStroke()
            Drag.ERASE -> { diffEdit(sessionStart, elements)?.let { history().record(it); refreshFlags() } }
            Drag.AREA -> finishArea()
            Drag.SHAPE -> commitShape()
            Drag.TEXT_TAP -> if (!moved) openTextAt(startWorld)
            Drag.MOVE, Drag.RESIZE, Drag.ROTATE -> {
                val o = dragOriginal
                val now = o?.let { orig -> elements.firstOrNull { it.id == orig.id } }
                if (moved && o != null && now != null) {
                    history().record(Edit.Update(listOf(o), listOf(now)))
                    refreshFlags()
                }
            }
            else -> Unit
        }
        resetInteraction()
    }

    /** إلغاء التفاعل (مثلًا عند نزول إصبع ثانٍ) والرجوع للحالة قبل البدء. */
    fun cancelInteraction() {
        when (drag) {
            Drag.ERASE -> setElements(sessionStart)
            Drag.MOVE, Drag.RESIZE, Drag.ROTATE -> dragOriginal?.let { replaceElement(it) }
            else -> Unit
        }
        resetInteraction()
    }

    private fun resetInteraction() {
        drag = Drag.NONE; moved = false; dragOriginal = null
        livePts.clear(); liveShape = null; cursorWorld = null; areaRect = null
        liveVersion++
    }

    // ───────── قلم ─────────
    private fun commitStroke() {
        if (livePts.isEmpty()) return
        if (hypot(lastWorld.x - livePts.last().x, lastWorld.y - livePts.last().y) > 0.01f && livePts.size > 1)
            livePts.add(Pt(lastWorld.x, lastWorld.y, livePts.last().p))
        val st = style(activeTool)
        val s = Stroke(newId(), penFor(activeTool), st.color, st.size, st.opacity, resample(livePts.toList()))
        insert(s)
    }

    /** يملأ الفراغات بين نقاط بعيدة (حركة سريعة) ليعمل المسح بالبكسل بدقة. */
    private fun resample(pts: List<Pt>, maxGap: Float = 8f): List<Pt> {
        if (pts.size < 2) return pts
        val out = ArrayList<Pt>(pts.size)
        out.add(pts[0])
        for (i in 1 until pts.size) {
            val a = pts[i - 1]; val b = pts[i]
            val n = (hypot(b.x - a.x, b.y - a.y) / maxGap).toInt()
            for (k in 1..n) {
                val t = k.toFloat() / (n + 1)
                out.add(Pt(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t, a.p + (b.p - a.p) * t))
            }
            out.add(b)
        }
        return out
    }

    // ───────── أشكال ─────────
    private fun updateLiveShape(p: Offset) {
        val st = style(Tool.SHAPES)
        val end = ShapePaths.snapEnd(shapeType, startWorld.x, startWorld.y, p.x, p.y)
        val fill = if (shapeFill && ShapePaths.isClosed(shapeType)) (st.color and 0x00FFFFFFL) or (0x40L shl 24) else null
        liveShape = ShapeElement(
            id = "live", shape = shapeType, color = st.color, strokeWidth = st.size, fillColor = fill,
            x1 = startWorld.x, y1 = startWorld.y, x2 = end.x, y2 = end.y,
        )
    }

    private fun commitShape() {
        val s = liveShape ?: return
        if (hypot(s.x2 - s.x1, s.y2 - s.y1) < 4f / viewScale) return
        insert(s.copy(id = newId()))
    }

    // ───────── ممحاة ─────────
    private fun eraseAt(p: Offset) {
        val r = eraserSize / viewScale / 2f
        val list = elements
        when (eraserMode) {
            EraserMode.PIXEL -> {
                val res = pixelErase(list, p, r)
                if (res !== list) setElements(res)
            }
            EraserMode.STROKE -> {
                val res = list.filterNot { it is Stroke && Geometry.hit(it, p.x, p.y, r) }
                if (res.size != list.size) setElements(res)
            }
            EraserMode.OBJECT -> {
                val res = list.filterNot { Geometry.hit(it, p.x, p.y, r) }
                if (res.size != list.size) setElements(res)
            }
            EraserMode.AREA -> Unit
        }
        if (selected == null) selectedId = null
    }

    private fun pixelErase(list: List<Element>, c: Offset, r: Float): List<Element> {
        var changed = false
        val out = ArrayList<Element>(list.size)
        for (e in list) {
            if (e !is Stroke) { out.add(e); continue }
            val wb = Geometry.worldBounds(e)
            if (!wb.inflate(r + e.width * e.transform.scale).contains(c.x, c.y)) { out.add(e); continue }
            val s = if (e.transform == Transform()) e else Geometry.bake(e)
            val rr = r + s.width / 2f
            val rr2 = rr * rr
            val runs = ArrayList<List<Pt>>()
            var cur = ArrayList<Pt>()
            var hit = false
            for (pt in s.points) {
                val dx = pt.x - c.x; val dy = pt.y - c.y
                if (dx * dx + dy * dy <= rr2) {
                    hit = true
                    if (cur.isNotEmpty()) { runs.add(cur); cur = ArrayList() }
                } else cur.add(pt)
            }
            if (cur.isNotEmpty()) runs.add(cur)
            if (!hit) { out.add(e); continue }
            changed = true
            for (run in runs) out.add(s.copy(id = newId(), points = run))
        }
        return if (changed) out else list
    }

    private fun finishArea() {
        val r = areaRect ?: return
        val area = Bounds(r.left, r.top, r.right, r.bottom)
        val kept = elements.filterNot { Geometry.worldBounds(it).intersects(area) }
        if (kept.size != elements.size) {
            val before = elements
            setElements(kept)
            diffEdit(before, kept)?.let { history().record(it); refreshFlags() }
        }
    }

    // ───────── تحديد وتحريك ─────────
    private fun beginSelect(screen: Offset, p: Offset) {
        val sel = selected
        if (sel != null) {
            val hr = 26f / viewScale
            val ctr = Geometry.worldCenter(sel)
            if ((p - Geometry.resizeHandle(sel)).getDistance() <= hr) {
                dragOriginal = sel; drag = Drag.RESIZE
                startDist = max((p - ctr).getDistance(), 1f)
                return
            }
            if ((p - Geometry.rotateHandle(sel, 44f / viewScale)).getDistance() <= hr) {
                dragOriginal = sel; drag = Drag.ROTATE
                startAngle = atan2(p.y - ctr.y, p.x - ctr.x)
                return
            }
        }
        val hit = elements.asReversed().firstOrNull { Geometry.hit(it, p.x, p.y, 10f / viewScale) }
        if (hit != null) {
            selectedId = hit.id; dragOriginal = hit; drag = Drag.MOVE
        } else {
            selectedId = null; drag = Drag.PAN; lastScreen = screen
        }
    }

    private fun dragSelection(p: Offset) {
        val o = dragOriginal ?: return
        val t = o.transform
        when (drag) {
            Drag.MOVE -> {
                val d = p - startWorld
                if (!moved && d.getDistance() < 3f / viewScale) return
                moved = true
                replaceElement(o.withTransform(t.copy(tx = t.tx + d.x, ty = t.ty + d.y)))
            }
            Drag.RESIZE -> {
                val ctr = Geometry.worldCenter(o)
                val f = (p - ctr).getDistance() / startDist
                moved = true
                replaceElement(o.withTransform(t.copy(scale = (t.scale * f).coerceIn(0.05f, 40f))))
            }
            Drag.ROTATE -> {
                val ctr = Geometry.worldCenter(o)
                val delta = Math.toDegrees((atan2(p.y - ctr.y, p.x - ctr.x) - startAngle).toDouble()).toFloat()
                var rot = t.rotation + delta
                val snapped = (rot / 15f).roundToInt() * 15f
                if (kotlin.math.abs(rot - snapped) < 4f) rot = snapped
                moved = true
                replaceElement(o.withTransform(t.copy(rotation = rot)))
            }
            else -> Unit
        }
    }

    private fun openTextAt(p: Offset) {
        val hit = elements.asReversed().firstOrNull { it is TextElement && Geometry.hit(it, p.x, p.y, 10f / viewScale) }
        textEdit = TextEditRequest(p, hit as? TextElement)
    }
}
