package com.yousif.boardplus.whiteboard.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Redo
import androidx.compose.material.icons.automirrored.rounded.Undo
import androidx.compose.material.icons.rounded.AddCircleOutline
import androidx.compose.material.icons.rounded.Category
import androidx.compose.material.icons.rounded.CenterFocusStrong
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.FileCopy
import androidx.compose.material.icons.rounded.GridOn
import androidx.compose.material.icons.rounded.Highlight
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.NearMe
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.TextFields
import androidx.compose.material.icons.rounded.Brush
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.yousif.boardplus.MainActivity
import com.yousif.boardplus.R
import com.yousif.boardplus.ui.theme.YbpColors
import com.yousif.boardplus.whiteboard.WhiteboardViewModel
import com.yousif.boardplus.whiteboard.engine.BoardController
import com.yousif.boardplus.whiteboard.engine.Geometry
import com.yousif.boardplus.whiteboard.engine.Tool
import com.yousif.boardplus.whiteboard.model.BoardBackground
import com.yousif.boardplus.whiteboard.model.TextElement
import kotlin.math.roundToInt

@Composable
fun WhiteboardScreen(onExit: () -> Unit, vm: WhiteboardViewModel = viewModel()) {
    val c = vm.board
    ImmersiveEffect()
    BackHandler { if (c.selectedId != null) c.deselect() else onExit() }

    BoxWithConstraints(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        val compact = maxWidth < 700.dp
        Column(Modifier.fillMaxSize()) {
            TopBar(c, onExit)
            if (compact) {
                Box(Modifier.weight(1f).fillMaxWidth()) { BoardArea(c) }
                ToolPanel(c, Modifier.fillMaxWidth().heightIn(max = 170.dp))
                ToolRail(c, vertical = false, modifier = Modifier.fillMaxWidth())
            } else {
                Row(Modifier.weight(1f).fillMaxWidth()) {
                    ToolRail(c, vertical = true, modifier = Modifier.fillMaxHeight())
                    Box(Modifier.weight(1f).fillMaxHeight()) { BoardArea(c) }
                    Surface(color = MaterialTheme.colorScheme.surface, modifier = Modifier.width(290.dp).fillMaxHeight()) {
                        ToolPanel(c, Modifier.fillMaxSize())
                    }
                }
            }
        }
    }
    TextEditorDialog(c)
}

@Composable
private fun ImmersiveEffect() {
    val ctx = LocalContext.current
    DisposableEffect(Unit) {
        val act = ctx.findActivity() as? MainActivity
        act?.setImmersive(true)
        onDispose { act?.setImmersive(false) }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

// ───────── الشريط العلوي ─────────
@Composable
private fun TopBar(c: BoardController, onExit: () -> Unit) {
    var bgMenu by remember { mutableStateOf(false) }
    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BarButton(Icons.Rounded.Home, R.string.wb_home, true, onExit)
            Text(
                text = c.document.title.ifBlank { stringResource(R.string.dash_new_whiteboard) },
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                modifier = Modifier.weight(1f).padding(horizontal = 12.dp),
            )
            BarButton(Icons.AutoMirrored.Rounded.Undo, R.string.wb_undo, c.canUndo) { c.undo() }
            BarButton(Icons.AutoMirrored.Rounded.Redo, R.string.wb_redo, c.canRedo) { c.redo() }
            Box {
                BarButton(Icons.Rounded.GridOn, R.string.wb_background, true) { bgMenu = true }
                DropdownMenu(expanded = bgMenu, onDismissRequest = { bgMenu = false }) {
                    listOf(
                        BoardBackground.WHITE to R.string.bg_white,
                        BoardBackground.BLACK to R.string.bg_black,
                        BoardBackground.GRID to R.string.bg_grid,
                        BoardBackground.DOTS to R.string.bg_dots,
                        BoardBackground.NOTEBOOK to R.string.bg_notebook,
                        BoardBackground.MATH_GRID to R.string.bg_math,
                    ).forEach { (bg, label) ->
                        DropdownMenuItem(
                            text = { Text(stringResource(label), style = MaterialTheme.typography.bodyLarge) },
                            onClick = { c.setBackground(bg); bgMenu = false },
                        )
                    }
                }
            }
            BarButton(Icons.Rounded.DeleteSweep, R.string.wb_clear, c.elements.isNotEmpty()) { c.clearPage() }
        }
    }
}

@Composable
private fun BarButton(icon: ImageVector, label: Int, enabled: Boolean, onClick: () -> Unit) {
    IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(56.dp)) {
        Icon(icon, stringResource(label), modifier = Modifier.size(28.dp))
    }
}

// ───────── شريط الأدوات ─────────
private data class ToolDef(val tool: Tool, val icon: ImageVector, val label: Int)

private val toolDefs = listOf(
    ToolDef(Tool.SELECT, Icons.Rounded.NearMe, R.string.tool_select),
    ToolDef(Tool.PEN, Icons.Rounded.Edit, R.string.tool_pen),
    ToolDef(Tool.MARKER, Icons.Rounded.Brush, R.string.tool_marker),
    ToolDef(Tool.HIGHLIGHTER, Icons.Rounded.Highlight, R.string.tool_highlighter),
    ToolDef(Tool.ERASER, Icons.Rounded.CleaningServices, R.string.tool_eraser),
    ToolDef(Tool.SHAPES, Icons.Rounded.Category, R.string.tool_shapes),
    ToolDef(Tool.TEXT, Icons.Rounded.TextFields, R.string.tool_text),
    // المراحل اللاحقة: صورة، PDF، رياضيات، أدوات
)

@Composable
private fun ToolRail(c: BoardController, vertical: Boolean, modifier: Modifier = Modifier) {
    Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp, modifier = modifier) {
        if (vertical) {
            Column(
                Modifier.verticalScroll(rememberScrollState()).padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) { toolDefs.forEach { ToolButton(it, c.tool == it.tool) { c.selectTool(it.tool) } } }
        } else {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) { toolDefs.forEach { ToolButton(it, c.tool == it.tool) { c.selectTool(it.tool) } } }
        }
    }
}

@Composable
private fun ToolButton(def: ToolDef, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) YbpColors.Electric else Color.Transparent
    val fg = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
    Column(
        Modifier.size(width = 76.dp, height = 76.dp)
            .background(bg, RoundedCornerShape(18.dp))
            .clickable(role = Role.Tab, onClick = onClick)
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(def.icon, null, tint = fg, modifier = Modifier.size(30.dp))
        Text(stringResource(def.label), color = fg, style = MaterialTheme.typography.labelLarge, maxLines = 1)
    }
}

// ───────── منطقة السبورة + القائمة العائمة ─────────
@Composable
private fun BoardArea(c: BoardController) {
    Box(Modifier.fillMaxSize()) {
        BoardCanvas(c, Modifier.fillMaxSize())
        SelectionMenu(c)
        if (c.viewScale != 1f || c.viewOffset != androidx.compose.ui.geometry.Offset.Zero) {
            Surface(
                shape = RoundedCornerShape(50), tonalElevation = 6.dp, shadowElevation = 6.dp,
                modifier = Modifier.align(Alignment.BottomStart).padding(16.dp),
            ) {
                Row(
                    Modifier.clickable { c.resetView() }.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(Icons.Rounded.CenterFocusStrong, stringResource(R.string.wb_reset_view))
                    Text("${(c.viewScale * 100).roundToInt()}%", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}

@Composable
private fun SelectionMenu(c: BoardController) {
    val sel = c.selected ?: return
    if (c.tool != Tool.SELECT) return
    val wb = Geometry.worldBounds(sel)
    val sx = c.viewOffset.x + wb.cx * c.viewScale
    val sy = c.viewOffset.y + wb.t * c.viewScale
    var menuW by remember { mutableIntStateOf(0) }
    Surface(
        shape = RoundedCornerShape(22.dp), tonalElevation = 8.dp, shadowElevation = 10.dp,
        modifier = Modifier
            .offset { IntOffset((sx - menuW / 2f).roundToInt().coerceAtLeast(8), (sy - 100.dp.toPx()).roundToInt().coerceAtLeast(8)) }
            .onSizeChanged { menuW = it.width },
    ) {
        Row(Modifier.padding(6.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            if (sel is TextElement) BarButton(Icons.Rounded.Edit, R.string.sel_edit, true) { c.editSelectedText() }
            BarButton(Icons.Rounded.FileCopy, R.string.sel_duplicate, true) { c.duplicateSelected() }
            BarButton(Icons.Rounded.ContentCopy, R.string.sel_copy, true) { c.copySelected() }
            BarButton(Icons.Rounded.ContentPaste, R.string.sel_paste, c.hasClipboard) { c.paste() }
            BarButton(Icons.Rounded.RotateRight, R.string.sel_rotate, true) { c.rotateSelected(15f) }
            BarButton(Icons.Rounded.AddCircleOutline, R.string.sel_bigger, true) { c.scaleSelected(1.15f) }
            BarButton(Icons.Rounded.RemoveCircleOutline, R.string.sel_smaller, true) { c.scaleSelected(1f / 1.15f) }
            BarButton(Icons.Rounded.Delete, R.string.sel_delete, true) { c.deleteSelected() }
        }
    }
}

@Composable
private fun TextEditorDialog(c: BoardController) {
    val req = c.textEdit ?: return
    var text by remember(req) { mutableStateOf(req.existing?.text ?: "") }
    AlertDialog(
        onDismissRequest = { c.dismissText() },
        text = {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                placeholder = { Text(stringResource(R.string.text_hint)) },
                minLines = 3, modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = { TextButton(onClick = { c.confirmText(text) }) { Text(stringResource(R.string.ok)) } },
        dismissButton = { TextButton(onClick = { c.dismissText() }) { Text(stringResource(R.string.cancel)) } },
    )
}
