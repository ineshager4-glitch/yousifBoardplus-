package com.yousif.boardplus.whiteboard.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * نموذج بيانات السبورة. كل الإحداثيات بوحدات السبورة (Board Units) وليست بكسلات،
 * لذلك تبقى الخطوط حادة عند التكبير وعلى شاشات Full HD / 2K / 4K.
 * كل عنصر: قابل للحفظ (Serializable)، للتحرير، للحذف، وللتحريك (Transform).
 */

@Serializable
data class Pt(val x: Float, val y: Float, val p: Float = 1f)

@Serializable
data class Transform(
    val tx: Float = 0f,
    val ty: Float = 0f,
    val scale: Float = 1f,
    val rotation: Float = 0f, // بالدرجات
)

@Serializable
enum class PenType { PEN, MARKER, PENCIL, HIGHLIGHTER, CALLIGRAPHY }

@Serializable
enum class ShapeType { LINE, ARROW, RECTANGLE, ROUNDED_RECT, CIRCLE, ELLIPSE, TRIANGLE, POLYGON, STAR }

@Serializable
enum class BoardBackground { WHITE, BLACK, GRID, DOTS, NOTEBOOK, MATH_GRID }

@Serializable
sealed interface Element {
    val id: String
    val transform: Transform
    fun withTransform(t: Transform): Element
    fun withId(id: String): Element
}

@Serializable
@SerialName("stroke")
data class Stroke(
    override val id: String,
    val pen: PenType,
    val color: Long,        // ARGB
    val width: Float,       // وحدات السبورة
    val opacity: Float,
    val points: List<Pt>,
    override val transform: Transform = Transform(),
) : Element {
    override fun withTransform(t: Transform) = copy(transform = t)
    override fun withId(id: String) = copy(id = id)
}

@Serializable
@SerialName("shape")
data class ShapeElement(
    override val id: String,
    val shape: ShapeType,
    val color: Long,
    val strokeWidth: Float,
    val fillColor: Long? = null,
    val x1: Float, val y1: Float, val x2: Float, val y2: Float,
    val sides: Int = 5, // للمضلع والنجمة
    override val transform: Transform = Transform(),
) : Element {
    override fun withTransform(t: Transform) = copy(transform = t)
    override fun withId(id: String) = copy(id = id)
}

@Serializable
@SerialName("text")
data class TextElement(
    override val id: String,
    val text: String,
    val x: Float, val y: Float,
    val fontSize: Float = 28f,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val align: String = "start", // start | center | end
    val color: Long = 0xFF000000,
    override val transform: Transform = Transform(),
) : Element {
    override fun withTransform(t: Transform) = copy(transform = t)
    override fun withId(id: String) = copy(id = id)
}

@Serializable
@SerialName("image")
data class ImageElement(
    override val id: String,
    val assetName: String, // اسم الملف داخل مجلد assets الخاص بالدرس
    val x: Float, val y: Float, val w: Float, val h: Float,
    val cropL: Float = 0f, val cropT: Float = 0f, val cropR: Float = 1f, val cropB: Float = 1f,
    override val transform: Transform = Transform(),
) : Element {
    override fun withTransform(t: Transform) = copy(transform = t)
    override fun withId(id: String) = copy(id = id)
}

@Serializable
@SerialName("pdf")
data class PdfElement(
    override val id: String,
    val assetName: String,
    val pageIndex: Int,
    val x: Float, val y: Float, val w: Float, val h: Float,
    override val transform: Transform = Transform(),
) : Element {
    override fun withTransform(t: Transform) = copy(transform = t)
    override fun withId(id: String) = copy(id = id)
}

@Serializable
data class WhiteboardPage(
    val id: String,
    val name: String,
    val background: BoardBackground = BoardBackground.WHITE,
    val elements: List<Element> = emptyList(),
)

@Serializable
data class WhiteboardDocument(
    val id: String,
    val title: String,
    val createdAt: Long,
    val updatedAt: Long,
    val pages: List<WhiteboardPage>,
    val formatVersion: Int = 1,
)
