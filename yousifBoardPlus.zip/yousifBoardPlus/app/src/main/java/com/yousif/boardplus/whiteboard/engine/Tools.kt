package com.yousif.boardplus.whiteboard.engine

import androidx.compose.ui.geometry.Offset
import com.yousif.boardplus.whiteboard.model.TextElement

enum class Tool { SELECT, PEN, MARKER, HIGHLIGHTER, ERASER, SHAPES, TEXT }

/** PIXEL: يقص الحبر نفسه. STROKE: يحذف الخط كاملًا. OBJECT: يحذف أي عنصر. AREA: يمسح منطقة مرسومة. */
enum class EraserMode { PIXEL, STROKE, OBJECT, AREA }

data class ToolStyle(val color: Long, val size: Float, val opacity: Float)

data class TextStyleState(
    val color: Long = 0xFF000000,
    val size: Float = 32f,
    val bold: Boolean = false,
    val italic: Boolean = false,
    val align: String = "start",
)

data class TextEditRequest(val pos: Offset, val existing: TextElement?)

object BoardPalette {
    val colors: List<Long> = listOf(
        0xFF000000, // Black
        0xFFFFFFFF, // White
        0xFFE5484D, // Red
        0xFF2F6BFF, // Blue
        0xFF1FB57A, // Green
        0xFFFFD60A, // Yellow
        0xFFFF8A1F, // Orange
        0xFF8E4EC6, // Purple
        0xFFFF5FA2, // Pink
    )
}
