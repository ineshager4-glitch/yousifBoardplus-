package com.yousif.boardplus.whiteboard.engine

import java.util.UUID

fun newId(): String = UUID.randomUUID().toString()
