package com.yousif.boardplus

import com.yousif.boardplus.whiteboard.history.Edit
import com.yousif.boardplus.whiteboard.history.EditHistory
import com.yousif.boardplus.whiteboard.history.diffEdit
import com.yousif.boardplus.whiteboard.model.Element
import com.yousif.boardplus.whiteboard.model.ShapeElement
import com.yousif.boardplus.whiteboard.model.ShapeType
import com.yousif.boardplus.whiteboard.model.Transform
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryTest {

    private fun el(id: String): Element =
        ShapeElement(id, ShapeType.LINE, 0xFF000000, 2f, null, 0f, 0f, 10f, 10f)

    @Test fun insertThenUndoRestoresEmpty() {
        val h = EditHistory()
        var list: List<Element> = emptyList()
        val edit = Edit.Insert(listOf(0 to el("a")))
        list = edit.apply(list); h.record(edit)
        assertEquals(listOf("a"), list.map { it.id })
        list = h.undo(list)!!
        assertTrue(list.isEmpty())
        list = h.redo(list)!!
        assertEquals(listOf("a"), list.map { it.id })
    }

    @Test fun deleteUndoRestoresOriginalZOrder() {
        val start = listOf(el("a"), el("b"), el("c"))
        val del = Edit.Delete(listOf(0 to start[0], 2 to start[2]))
        val afterDelete = del.apply(start)
        assertEquals(listOf("b"), afterDelete.map { it.id })
        assertEquals(listOf("a", "b", "c"), del.inverse().apply(afterDelete).map { it.id })
    }

    @Test fun updateIsReversible() {
        val a = el("a")
        val moved = a.withTransform(Transform(tx = 50f))
        val u = Edit.Update(listOf(a), listOf(moved))
        val after = u.apply(listOf(a))
        assertEquals(50f, after[0].transform.tx, 0f)
        assertEquals(0f, u.inverse().apply(after)[0].transform.tx, 0f)
    }

    @Test fun newEditClearsRedo() {
        val h = EditHistory()
        h.record(Edit.Insert(listOf(0 to el("a"))))
        h.undo(listOf(el("a")))
        assertTrue(h.canRedo)
        h.record(Edit.Insert(listOf(0 to el("b"))))
        assertFalse(h.canRedo)
    }

    @Test fun largeHistoryKeepsThousandsOfOperations() {
        val h = EditHistory()
        repeat(5000) { h.record(Edit.Insert(listOf(0 to el("e$it")))) }
        var count = 0
        var list: List<Element> = (0 until 5000).map { el("e$it") }
        while (true) { list = h.undo(list) ?: break; count++ }
        assertEquals(5000, count)
    }

    @Test fun diffEditDetectsPixelEraseSplit() {
        val before = listOf(el("a"), el("b"), el("c"))
        val after = listOf(el("a"), el("b1"), el("b2"), el("c"))
        val edit = diffEdit(before, after)!!
        assertEquals(after.map { it.id }, edit.apply(before).map { it.id })
        assertEquals(before.map { it.id }, edit.inverse().apply(after).map { it.id })
    }

    @Test fun diffEditNullWhenUnchanged() {
        val l = listOf(el("a"))
        assertNull(diffEdit(l, l))
    }
}
