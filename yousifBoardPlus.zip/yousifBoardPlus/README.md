# yousifBoardPlus
Smart Interactive Whiteboard for Android (Kotlin + Jetpack Compose + Material 3).
Package: com.yousif.boardplus · versionName 1.0.0 · minSdk 24 · targetSdk 35

## الفتح والبناء
1. Android Studio (Koala أو أحدث) ← Open ← مجلد yousifBoardPlus
2. انتظر Gradle Sync (يُنشئ gradle-wrapper.jar تلقائيًا)
3. Run ▶ أو: Build ▸ Build APK(s)

## الحالة (المراحل المنجزة)
1–4: المشروع، Gradle، الثيم، التنقل، Dashboard · 5–6: محرك السبورة (أقلام، ممحاة، أشكال، تحديد، نص، Undo/Redo، Pan/Zoom)
